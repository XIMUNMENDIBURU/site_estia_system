-- estia_system.sql — Schéma SQLite pour l'application Estia System
-- Encodage : UTF-8
-- Usage : sqlite3 data/estia_system.db < data/estia_system.sql

PRAGMA foreign_keys = ON;

-- ===============================
-- Table: admin (comptes administrateurs)
-- ===============================
CREATE TABLE IF NOT EXISTS admin (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  username   TEXT    NOT NULL UNIQUE,
  password   TEXT    NOT NULL,            -- stocker un hash (password_hash)
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Index utile si on fait souvent des recherches par username
CREATE UNIQUE INDEX IF NOT EXISTS idx_admin_username ON admin(username);

-- ===============================
-- Table: users (utilisateurs “membres” gérés par les admins)
-- ===============================
CREATE TABLE IF NOT EXISTS users (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  nom          TEXT    NOT NULL,
  prenom       TEXT    NOT NULL,
  identifiant  TEXT    NOT NULL UNIQUE,   -- ex: “p.dupont”
  password     TEXT    NOT NULL,          -- idéalement un hash ; évite le clair
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by   INTEGER,
  FOREIGN KEY (created_by) REFERENCES admin(id) ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_identifiant ON users(identifiant);

-- ===============================
-- (Optionnel) Compte admin par défaut
-- Remplir avec un hash BCRYPT réel (placeholder ci‑dessous).
-- Pour générer un hash: password_hash('TonMotDePasse', PASSWORD_BCRYPT) en PHP
-- ===============================
-- INSERT INTO admin (username, password) VALUES ('Admin', '$2y$10$PLACEHOLDER_HASH');
